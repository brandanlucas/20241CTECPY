"""
Ejercicio 1.5
Crea una clase base llamada Animal con atributos como nombre y edad. 
Luego, define clases derivadas como Perro, Gato, etc., 
que agreguen atributos específicos y métodos relacionados con cada tipo de animal.
"""

# Clase base
class Animal:
    def __init__(self, nombre, edad, raza = None):
        self.nombre = nombre  # Atributo que almacena el nombre del animal
        self.edad = edad      # Atributo que almacena la edad del animal
        self.raza = raza  #if not None else []
    def hacer_sonido(self):
        pass  # Método que puede ser implementado por clases derivadas


# Clase derivada
class Perro(Animal):
    def __init__(self, nombre, edad, raza, muerde):
        super().__init__(nombre, edad, raza)  # Llama al inicializador de variables de la  clase base
          # Atributo específico del perro
        self.muerde = muerde

    def hacer_sonido(self):
        return "¡Guauf!"  # Implementación del método para perros


# Clase derivada
class Gato(Animal):
    def __init__(self, nombre, edad, color):
        super().__init__(nombre, edad)  # Llama al constructor de la clase base
        self.color = color  # Atributo específico del gato

    def hacer_sonido(self):
        return "¡Miau!"  # Implementación del método para gatos
    
perrito = Perro ("Tina", 4, "PP", True)
print (f"Nombre:{perrito.nombre}")
print (f"Edad:{perrito.edad}")
print (f"Raza:{perrito.raza}")
print (f"El perro nuevo se llama: {perrito.nombre} , tiene: {perrito.edad} años, su raza es: {perrito.raza} el hace: {perrito.hacer_sonido()} y muerde {perrito.muerde}")

