"""
Ejercicio 1.2
Crea una clase Persona con atributos nombre y edad. 
Crea un método para imprimir los datos de la persona.
"""

class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def imprimir_datos(self):
        print(f"Nombre: {self.nombre}") 
        print(f"Edad: {self.edad}") 

persona1 = Persona("Betsa", 18)
persona1.imprimir_datos()

