"""
Define una clase abstracta llamada Empleado que tenga métodos abstractos
como calcular_sueldo() y generar_reporte(). Luego, crea clases concretas
como Desarrollador, Gerente, Contador, etc., que hereden de Empleado y
proporcionen implementaciones concretas para estos métodos
"""

from abc import ABC, abstractmethod

class Empleado(ABC):
    @abstractmethod
    def calcularSueldo(self, sueldo):
        self.sueldo = sueldo

    def generarReporte(self):
        pass


class Desarrollador(Empleado):
    def calcularSueldo(self, sueldo, cantHoras):
        super().__init__(self, sueldo)
        self.cantHoras = cantHoras
                
                       
                       
