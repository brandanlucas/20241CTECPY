"""
Ejercicio 1.4
Crea una clase Cancion que tenga atributos como nombre, artista y duracion. 
Crea métodos para reproducir la canción y para mostrar sus detalles.
"""
class Cancion:
    def __init__(self, nombre, artista, duracion):
        self.nombre = nombre
        self.artista = artista
        self.duracion = duracion
    
    def reproducir(self):
        print(f"Reproduciendo: {self.nombre}")

    
    def mostrar_detalles(self):
        print("Información de la canción:")
        print(f"Nombre: {self.nombre}")
        print(f"Artista: {self.artista}")
        print(f"Duracion: {self.duracion}")

cancion1 = Cancion("Shape of You", "Ed Sheeran", 5)
cancion1.reproducir()
cancion1.mostrar_detalles()
