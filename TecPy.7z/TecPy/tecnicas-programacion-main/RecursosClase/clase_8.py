valor = 0
while valor < 10:
    print(f"Valor es menor a 10. {valor}")
    valor += 1

print("Termino el while")

