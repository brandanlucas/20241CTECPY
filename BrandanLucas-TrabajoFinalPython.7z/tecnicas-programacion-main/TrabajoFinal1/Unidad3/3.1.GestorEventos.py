"""
Ejercicio 3.1
Diseña e implementa un sistema completo de gestión de eventos en línea que permita a los usuarios
crear, buscar, registrarse y administrar eventos. 
Los eventos pueden ser conferencias, conciertos, reuniones, etc.
El sistema debe incluir funcionalidades avanzadas como recomendación de eventos, gestión de pagos, 
notificaciones en tiempo real, etc.


Gestión de cupos dinámicos:
Cada evento tiene una capacidad fija (capacidad) y un contador de asistentes (asistentes).
El método registrar_asistente verifica si hay espacio antes de incrementar el contador, 
simulando la gestión real de cupos.

Búsqueda de eventos:
El método buscar_evento recorre la lista de eventos para encontrar uno específico por su nombre. 
Si no encuentra coincidencia, devuelve None.

Manejo de errores:
Verificamos si el evento existe antes de intentar registrar asistentes, 
evitando errores y proporcionando mensajes informativos.

"""

# Clase que representa un evento
class Evento:
    def __init__(self, nombre, tipo, ubicacion, capacidad):
        # Cada evento tiene un nombre, tipo (conferencia, concierto, etc.), ubicación y capacidad
        self.nombre = nombre
        self.tipo = tipo
        self.ubicacion = ubicacion
        self.capacidad = capacidad  # Cantidad máxima de asistentes
        self.asistentes = 0  # Cantidad actual de asistentes registrados

    def registrar_asistente(self):
        # Incrementa la cantidad de asistentes si hay cupo disponible
        if self.asistentes < self.capacidad:
            self.asistentes += 1
            print(f"Asistente registrado en el evento '{self.nombre}'. Total asistentes: {self.asistentes}.")
        else:
            print(f"El evento '{self.nombre}' está completo. No se pueden registrar más asistentes.")

# Clase principal para gestionar el sistema de eventos
class SistemaEventos:
    def __init__(self):
        # Lista para almacenar los eventos
        self.eventos = []

    def crear_evento(self, evento):
        # Agrega un evento al sistema
        self.eventos.append(evento)
        print(f"Evento '{evento.nombre}' creado exitosamente.")

    def buscar_evento(self, nombre):
        # Busca un evento por su nombre
        for evento in self.eventos:
            if evento.nombre == nombre:
                return evento
        return None  # Devuelve None si no encuentra el evento

    def mostrar_eventos(self):
        # Muestra todos los eventos registrados
        print("Eventos registrados:")
        for evento in self.eventos:
            print(f"- {evento.nombre} ({evento.tipo}), Ubicación: {evento.ubicacion}, Capacidad: {evento.capacidad}, Asistentes: {evento.asistentes}")



# Ejemplo Ejecución
# Creamos el sistema de gestión de eventos
sistema_eventos = SistemaEventos()

# Creamos eventos
evento1 = Evento(nombre="Conferencia Python", tipo="Conferencia", ubicacion="Auditorio A", capacidad=50)
evento2 = Evento(nombre="Concierto Rock", tipo="Concierto", ubicacion="Estadio Central", capacidad=100)

# Registramos los eventos en el sistema
sistema_eventos.crear_evento(evento1)
sistema_eventos.crear_evento(evento2)

# Mostramos todos los eventos disponibles
sistema_eventos.mostrar_eventos()

# Registramos asistentes en el evento "Conferencia Python"
evento_a_registrar = sistema_eventos.buscar_evento("Conferencia Python")
if evento_a_registrar:
    evento_a_registrar.registrar_asistente()
    evento_a_registrar.registrar_asistente()

# Intentamos registrar asistentes en un evento inexistente
evento_inexistente = sistema_eventos.buscar_evento("Evento Fantasma")
if not evento_inexistente:
    print("El evento 'Evento Fantasma' no está registrado en el sistema.")

# Mostramos nuevamente los eventos con los asistentes actualizados
sistema_eventos.mostrar_eventos()
