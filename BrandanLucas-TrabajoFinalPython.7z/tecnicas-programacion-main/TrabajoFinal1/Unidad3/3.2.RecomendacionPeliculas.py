"""
Ejercicio 3.2
Desarrolla un sistema de recomendación de películas que sugiera películas a los usuarios en función de sus gustos previos
y las calificaciones de otras películas. Utiliza algoritmos de filtrado colaborativo o sistemas de recomendación basados
en contenido para generar recomendaciones personalizadas para cada usuario. 
Considera también la implementación de funciones avanzadas como la detección de tendencias, 
la recomendación de grupos y la retroalimentación del usuario.

Filtrado dinámico por género:
Usamos una lista por comprensión para obtener solo las películas del género deseado 
([p for p in self.peliculas if p.genero == genero]).

Ordenación basada en criterios:
recomendadas.sort(key=lambda p: p.promedio_calificaciones(), reverse=True)
ordena las películas según su promedio de calificaciones, de mayor a menor.
"""

# Clase que representa una película
class Pelicula:
    def __init__(self, titulo, genero):
        # Cada película tiene un título, género y lista de calificaciones
        self.titulo = titulo
        self.genero = genero
        self.calificaciones = []

    def agregar_calificacion(self, calificacion):
        # Añade una calificación a la lista
        self.calificaciones.append(calificacion)

    def promedio_calificaciones(self):
        # Calcula el promedio de las calificaciones
        return sum(self.calificaciones) / len(self.calificaciones) if self.calificaciones else 0

# Clase principal del sistema de recomendación
class SistemaRecomendacion:
    def __init__(self):
        # Lista para almacenar las películas
        self.peliculas = []

    def agregar_pelicula(self, pelicula):
        # Agrega una película al sistema
        self.peliculas.append(pelicula)
        print(f"Película '{pelicula.titulo}' agregada al sistema.")

    def recomendar_por_genero(self, genero):
        # Filtra las películas por género
        recomendadas = [p for p in self.peliculas if p.genero == genero]
        # Ordena las películas por promedio de calificaciones en orden descendente
        recomendadas.sort(key=lambda p: p.promedio_calificaciones(), reverse=True)
        print(f"Películas recomendadas en el género '{genero}':")
        for pelicula in recomendadas:
            print(f"- {pelicula.titulo}, Promedio: {pelicula.promedio_calificaciones():.2f}")



# Ejemplo Ejecicion
# Creamos el sistema de recomendación
sistema_recomendacion = SistemaRecomendacion()

# Creamos películas
pelicula1 = Pelicula(titulo="Avatar", genero="Ciencia Ficción")
pelicula2 = Pelicula(titulo="Harry Potter", genero="Ciencia Ficción")
pelicula3 = Pelicula(titulo="El Padrino", genero="Drama")

# Agregamos calificaciones a las películas
pelicula1.agregar_calificacion(5)
pelicula1.agregar_calificacion(4)
pelicula2.agregar_calificacion(5)
pelicula3.agregar_calificacion(3)

# Agregamos películas al sistema
sistema_recomendacion.agregar_pelicula(pelicula1)
sistema_recomendacion.agregar_pelicula(pelicula2)
sistema_recomendacion.agregar_pelicula(pelicula3)

# Recomendamos películas por género
sistema_recomendacion.recomendar_por_genero("Ciencia Ficción")
