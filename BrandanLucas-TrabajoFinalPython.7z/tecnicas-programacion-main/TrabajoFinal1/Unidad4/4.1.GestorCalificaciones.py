"""
Ejercicio 4.1
Desarrolla un programa en Python que permita gestionar las calificaciones de estudiantes en una institución educativa. 
El sistema debe permitir el registro de profesores, alumnos, asignaturas y calificaciones, 
así como calcular automáticamente el promedio y determinar la promoción de cada estudiante.

El sistema debe incluir las siguientes funcionalidades:
Registro de profesores: El sistema debe permitir el registro de profesores,
incluyendo su nombre y la asignatura que imparten.

Registro de alumnos: El sistema debe permitir el registro de alumnos,
incluyendo su nombre y el curso al que pertenecen.

Registro de asignaturas: El sistema debe permitir el registro de asignaturas,
incluyendo su nombre.

Registro de calificaciones: El sistema debe permitir el registro de
calificaciones de los alumnos en las diferentes asignaturas. Cada calificación
debe incluir el nombre del alumno, la asignatura, el profesor que la imparte y
la calificación obtenida.

Cálculo del promedio: El sistema debe calcular automáticamente el promedio
de calificaciones de cada alumno.

Determinación de la Promoción: El sistema debe determinar
automáticamente si un alumno está promocionado o no, en función de su
promedio de calificaciones.
"""



# Clase que representa un profesor
class Profesor:
    def __init__(self, nombre):
        # Cada profesor tiene un nombre
        self.nombre = nombre

# Clase que representa una materia
class Materia:
    def __init__(self, nombre):
        # Cada materia tiene un nombre
        self.nombre = nombre

# Clase que representa un estudiante
class Estudiante:
    def __init__(self, nombre, curso):
        # Cada estudiante tiene un nombre y pertenece a un curso
        self.nombre = nombre
        self.curso = curso
        self.calificaciones = {}  # Diccionario para almacenar calificaciones por materia

    def agregar_calificacion(self, materia, calificacion):
        # Añade una calificación para una materia específica
        if materia.nombre not in self.calificaciones:
            self.calificaciones[materia.nombre] = []
        self.calificaciones[materia.nombre].append(calificacion)
        print(f"Calificación {calificacion} agregada para {self.nombre} en {materia.nombre}.")

    def calcular_promedio(self):
        # Calcula el promedio de todas las calificaciones
        total_calificaciones = []
        for materia, notas in self.calificaciones.items():
            total_calificaciones.extend(notas)
        promedio = sum(total_calificaciones) / len(total_calificaciones) if total_calificaciones else 0
        print(f"Promedio de {self.nombre}: {promedio:.2f}")
        return promedio

    def esta_promocionado(self):
        # Determina si el estudiante está promocionado (promedio >= 7)
        promedio = self.calcular_promedio()
        if promedio >= 7:
            print(f"{self.nombre} está promocionado.")
            return True
        else:
            print(f"{self.nombre} no está promocionado.")
            return False

# Clase principal para gestionar el sistema educativo
class SistemaEducativo:
    def __init__(self):
        self.profesores = []
        self.estudiantes = []
        self.materias = []

    def registrar_profesor(self, profesor):
        self.profesores.append(profesor)
        print(f"Profesor {profesor.nombre} registrado.")

    def registrar_estudiante(self, estudiante):
        self.estudiantes.append(estudiante)
        print(f"Estudiante {estudiante.nombre} registrado.")

    def registrar_materia(self, materia):
        self.materias.append(materia)
        print(f"Materia {materia.nombre} registrada.")


# Ejemplo Ejecución

# Creamos el sistema educativo
sistema = SistemaEducativo()

# Registramos un profesor, materias y estudiantes
profesor1 = Profesor(nombre="Sr. López")
sistema.registrar_profesor(profesor1)

materia1 = Materia(nombre="Matemáticas")
materia2 = Materia(nombre="Historia")
sistema.registrar_materia(materia1)
sistema.registrar_materia(materia2)

estudiante1 = Estudiante(nombre="Ana", curso="Primero")
estudiante2 = Estudiante(nombre="Carlos", curso="Segundo")
sistema.registrar_estudiante(estudiante1)
sistema.registrar_estudiante(estudiante2)

# Agregamos calificaciones para los estudiantes
estudiante1.agregar_calificacion(materia1, 8)
estudiante1.agregar_calificacion(materia1, 9)
estudiante1.agregar_calificacion(materia2, 7)

estudiante2.agregar_calificacion(materia1, 6)
estudiante2.agregar_calificacion(materia2, 7)

# Calculamos el promedio y determinamos si están promocionados
estudiante1.calcular_promedio()
estudiante1.esta_promocionado()

estudiante2.calcular_promedio()
estudiante2.esta_promocionado()
