"""
Ejercicio 2.10
Imagina que estás desarrollando un sistema de gestión para una compañía de transporte. 
Tu objetivo es diseñar un conjunto de clases orientadas a objetos para manejar: 
vehículos, rutas, conductores y clientes.
Debes crear clases como 'Vehiculo', 'Ruta', 'Conductor' y 'Cliente'. 
Implementa herencia para representar diferentes tipos de vehículos, como 'Automovil' y 'Camion'.
Utiliza la composición para gestionar la relación entre rutas, conductores y clientes,
y asegúrate de que el diseño sea escalable para futuras funcionalidades del sistema de transporte

Separación de responsabilidades:
Las clases Vehiculo, Ruta, Conductor y Cliente encapsulan información específica de cada entidad.
El sistema principal (SistemaTransporte) actúa como gestor, permitiendo registrar y consultar estas entidades.
Iteración y visualización:
El método mostrar_rutas recorre la lista de rutas y las muestra de manera dinámica, 
asegurando que cualquier ruta registrada sea incluida.
"""

# Clases que representan las entidades básicas del sistema de transporte
class Vehiculo:
    def __init__(self, marca, tipo):
        # Un vehículo tiene una marca y un tipo (auto, camión, etc.)
        self.marca = marca
        self.tipo = tipo

class Ruta:
    def __init__(self, origen, destino):
        # Una ruta conecta dos lugares: origen y destino
        self.origen = origen
        self.destino = destino

class Conductor:
    def __init__(self, nombre):
        # Cada conductor tiene un nombre
        self.nombre = nombre

class Cliente:
    def __init__(self, nombre):
        # Cada cliente tiene un nombre
        self.nombre = nombre

# Clase principal para gestionar el sistema de transporte
class SistemaTransporte:
    def __init__(self):
        # Listas para almacenar las entidades
        self.vehiculos = []
        self.rutas = []
        self.conductores = []
        self.clientes = []

    def registrar_vehiculo(self, vehiculo):
        # Agrega un vehículo al sistema
        self.vehiculos.append(vehiculo)
        print(f"Vehículo '{vehiculo.marca}' registrado.")

    def registrar_ruta(self, ruta):
        # Agrega una ruta al sistema
        self.rutas.append(ruta)
        print(f"Ruta registrada: {ruta.origen} a {ruta.destino}.")

    def registrar_conductor(self, conductor):
        # Agrega un conductor al sistema
        self.conductores.append(conductor)
        print(f"Conductor '{conductor.nombre}' registrado.")

    def registrar_cliente(self, cliente):
        # Agrega un cliente al sistema
        self.clientes.append(cliente)
        print(f"Cliente '{cliente.nombre}' registrado.")

    def mostrar_rutas(self):
        # Este bucle recorre las rutas disponibles y las muestra
        print("Rutas disponibles:")
        for ruta in self.rutas:
            print(f"- {ruta.origen} a {ruta.destino}")


# Ejemplo Ejecución
# Creamos el sistema de transporte
sistema_transporte = SistemaTransporte()

# Creamos y registramos entidades
vehiculo1 = Vehiculo(marca="Jeep", tipo="Auto")
ruta1 = Ruta(origen="Buenos Aires", destino="Potrerillos")
conductor1 = Conductor(nombre="Lucas")
cliente1 = Cliente(nombre="Candela")

sistema_transporte.registrar_vehiculo(vehiculo1)
sistema_transporte.registrar_ruta(ruta1)
sistema_transporte.registrar_conductor(conductor1)
sistema_transporte.registrar_cliente(cliente1)

# Mostramos las rutas disponibles
sistema_transporte.mostrar_rutas()
