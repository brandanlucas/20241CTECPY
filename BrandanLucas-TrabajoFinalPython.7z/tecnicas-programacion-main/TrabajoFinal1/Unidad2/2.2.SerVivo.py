"""
Ejercicio: 2.2
Desarrolla un juego de simulación de vida donde los "seres" pueden ser
plantas, animales, personas, etc. Cada ser debe tener atributos como
energía, salud, edad, etc., y comportamientos específicos según su tipo.

    Este ejercicio introduce la idea de "seres vivos" con diferentes atributos y comportamientos.
    Introducimos la herencia, permitiendo que "Persona" y "Animal" hereden atributos y métodos de la clase base "SerVivo".
"""

# Clase base que representa un ser vivo genérico
class SerVivo:
    def __init__(self, nombre, energia, salud, edad):
        # Atributos básicos que tienen todos los seres vivos
        self.nombre = nombre
        self.energia = energia
        self.salud = salud
        self.edad = edad

    def mostrar_estado(self):
        # Método para mostrar los valores actuales de los atributos
        print(f"{self.nombre} - Energía: {self.energia}, Salud: {self.salud}, Edad: {self.edad}")

# Clase Persona, derivada de SerVivo
class Persona(SerVivo):
    def trabajar(self):
        # Nuevo comportamiento: trabajar reduce energía y salud
        print(f"{self.nombre} está trabajando...")
        self.energia -= 10
        self.salud -= 5

# Clase Animal, derivada de SerVivo
class Animal(SerVivo):
    def correr(self):
        # Nuevo comportamiento: correr reduce energía y salud
        print(f"{self.nombre} está corriendo...")
        self.energia -= 15
        self.salud -= 10



# Ejemplo Ejecución:
# Creamos un objeto Persona
juan = Persona(nombre="Juan", energia=100, salud=80, edad=30)

# Creamos un objeto Animal
perro = Animal(nombre="Rex", energia=70, salud=60, edad=5)

# Mostramos su estado inicial
juan.mostrar_estado()  # Salida: Juan - Energía: 100, Salud: 80, Edad: 30
perro.mostrar_estado()  # Salida: Rex - Energía: 70, Salud: 60, Edad: 5

# Realizamos acciones y volvemos a mostrar el estado
juan.trabajar()  # Salida: Juan está trabajando...
juan.mostrar_estado()  # Energía: 90, Salud: 75

perro.correr()  # Salida: Rex está corriendo...
perro.mostrar_estado()  # Energía: 55, Salud: 50

