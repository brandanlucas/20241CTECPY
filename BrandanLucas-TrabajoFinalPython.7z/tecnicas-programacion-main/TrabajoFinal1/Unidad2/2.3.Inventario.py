"""
Ejercicio 2.3
Implementa un sistema de gestión de inventario para una tienda que incluya
clases como Producto, Inventario, Proveedor, etc. El inventario debe ser
capaz de realizar operaciones como agregar productos, actualizar
existencias, etc.

    Este ejercicio introduce un sistema más completo con varios productos que se gestionan en conjunto.
    Introducimos la agregación, donde "Inventario" gestiona una lista de objetos "Producto".

    El bucle for:
    Permite recorrer todos los productos de la lista productos.
    Compara el atributo nombre de cada producto con el nombre especificado.
    Si encuentra coincidencia, actualiza la cantidad y detiene el bucle con break.
    La lista productos actúa como una estructura de datos dinámica que almacena objetos, permitiendo la gestión conjunta de los mismos.
"""


# Clase que representa un producto individual
class Producto:
    def __init__(self, nombre, precio):
        # Un producto tiene un nombre, un precio y una cantidad inicial de 0
        self.nombre = nombre
        self.precio = precio
        self.cantidad_disponible = 0

# Clase Inventario para gestionar varios productos
class Inventario:
    def __init__(self):
        # La lista "productos" almacena todos los productos del inventario
        self.productos = []

    def agregar_producto(self, producto):
        # Método para agregar un nuevo producto a la lista
        self.productos.append(producto)

    def actualizar_existencias(self, nombre, nueva_cantidad):
        # Este bucle "for" recorre cada producto para encontrar el que coincide por nombre
        for producto in self.productos:
            if producto.nombre == nombre:
                producto.cantidad_disponible = nueva_cantidad
                print(f"Existencias actualizadas: {producto.nombre} ahora tiene {producto.cantidad_disponible} unidades.")
                break  # Terminamos la búsqueda tras actualizar el producto

    def mostrar_inventario(self):
        # Este bucle "for" muestra información de cada producto almacenado en la lista
        print("Inventario actual:")
        for producto in self.productos:
            print(f"- {producto.nombre}: Precio ${producto.precio}, Cantidad disponible: {producto.cantidad_disponible}")



# Ejemplo Ejecución:
# Creamos productos
manzanas = Producto(nombre="Manzana", precio=1500)
naranjas = Producto(nombre="Naranja", precio=2000)

# Creamos el inventario y agregamos productos
mi_inventario = Inventario()
mi_inventario.agregar_producto(manzanas)
mi_inventario.agregar_producto(naranjas)

# Mostramos el inventario inicial
mi_inventario.mostrar_inventario()
# Salida:
# Inventario actual:
# - Manzana: Precio $1.500, Cantidad disponible: 0
# - Naranja: Precio $2.000, Cantidad disponible: 0

# Actualizamos existencias y mostramos el inventario nuevamente
mi_inventario.actualizar_existencias(nombre="Manzana", nueva_cantidad=100)
mi_inventario.actualizar_existencias(nombre="Naranja", nueva_cantidad=50)

mi_inventario.mostrar_inventario()
# Salida:
# Inventario actual:
# - Manzana: Precio $1.500, Cantidad disponible: 100
# - Naranja: Precio $2.000, Cantidad disponible: 50
