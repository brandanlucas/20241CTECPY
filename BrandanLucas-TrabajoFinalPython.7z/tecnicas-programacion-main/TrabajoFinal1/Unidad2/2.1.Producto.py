"""
Ejercicio 2.1
Crea una clase llamada Producto que tenga atributos como nombre, precio y
cantidad_disponible. Implementa métodos para actualizar la cantidad
disponible y para mostrar la información del producto.
"""

# Esta clase representa un producto con atributos básicos
class Producto:
    def __init__(self, nombre, precio, cantidad_disponible):
        # Inicializamos los atributos del producto
        self.nombre = nombre
        self.precio = precio
        self.cantidad_disponible = cantidad_disponible

    def actualizar_cantidad(self, cantidad):
        # Método para actualizar la cantidad disponible del producto
        self.cantidad_disponible = cantidad

    def mostrar_informacion(self):
        # Método para mostrar información del producto
        print(f"Producto: {self.nombre}, Precio: {self.precio}, Cantidad disponible: {self.cantidad_disponible}")
