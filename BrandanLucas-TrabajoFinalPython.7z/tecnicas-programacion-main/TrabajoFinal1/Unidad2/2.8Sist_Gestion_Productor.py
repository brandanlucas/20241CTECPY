"""
Ejercicio 2.8
Imagina que estás desarrollando un sistema de gestión para una empresa de comercio electrónico. 
Tu tarea es diseñar un conjunto de clases orientadas a objetos para manejar:
productos, carritos de compra, usuarios y pedidos.

Debes crear clases como 'Producto', 'Carrito', 'Usuario' y 'Pedido'. 
Aplica herencia para representar diferentes tipos de usuarios, como 'Cliente' y 'Administrador'. 
Utiliza la composición para gestionar la relación entre productos y carritos, y asegúrate de que el diseño 
sea escalable para futuras características del comercio electrónico.

Composición de clases:
Cada usuario tiene su propio carrito.
Los productos dentro del carrito se usan para crear pedidos, manteniendo la información organizada y modular.
Suma dinámica con sum:
sum(producto.precio for producto in self.productos)
permite calcular el total de los precios de los productos en una línea, iterando sobre la lista.
"""



# Clase que representa un producto
class Producto:
    def __init__(self, nombre, precio):
        # Atributos básicos del producto
        self.nombre = nombre
        self.precio = precio

# Clase que representa un carrito de compras
class Carrito:
    def __init__(self):
        # Lista para almacenar productos en el carrito
        self.productos = []

    def agregar_producto(self, producto):
        # Agregamos un producto a la lista
        self.productos.append(producto)
        print(f"Producto '{producto.nombre}' agregado al carrito.")

    def mostrar_carrito(self):
        # Mostramos todos los productos del carrito
        print("Productos en el carrito:")
        for producto in self.productos:
            print(f"- {producto.nombre}, Precio: ${producto.precio}")

    def calcular_total(self):
        # Calculamos el total sumando los precios de todos los productos
        total = sum(producto.precio for producto in self.productos)
        print(f"Total del carrito: ${total}")
        return total

# Clase que representa un usuario
class Usuario:
    def __init__(self, nombre, email):
        # Cada usuario tiene su propio carrito
        self.nombre = nombre
        self.email = email
        self.carrito = Carrito()

# Clase que representa un pedido
class Pedido:
    def __init__(self, usuario, productos):
        # Asociamos el usuario y los productos al pedido
        self.usuario = usuario
        self.productos = productos

    def realizar_pedido(self):
        # Mostramos detalles del pedido
        print(f"Pedido realizado por {self.usuario.nombre}:")
        for producto in self.productos:
            print(f"- {producto.nombre}, Precio: ${producto.precio}")


# Ejemplo Ejecición:
# Creamos productos
producto1 = Producto(nombre="Juego de Canillas Macho", precio=4000)
producto2 = Producto(nombre="Resistencia", precio=8000)

# Creamos un usuario
usuario = Usuario(nombre="Lucas", email="LucasAndresBrandan@gmail.com")

# El usuario agrega productos a su carrito
usuario.carrito.agregar_producto(producto1)
usuario.carrito.agregar_producto(producto2)

# Mostramos el carrito y calculamos el total
usuario.carrito.mostrar_carrito()
usuario.carrito.calcular_total()

# Creamos un pedido con los productos del carrito
pedido = Pedido(usuario=usuario, productos=usuario.carrito.productos)

# Realizamos el pedido
pedido.realizar_pedido()

usuario.carrito.mostrar_carrito()

usuario.carrito.calcular_total()
