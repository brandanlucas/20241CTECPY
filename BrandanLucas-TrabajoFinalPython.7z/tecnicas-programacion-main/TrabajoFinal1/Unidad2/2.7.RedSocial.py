"""
Ejercicio 2.7
Crea un simulador de una red social donde los usuarios puedan registrarse,
agregar amigos, publicar mensajes, etc. Debe haber clases como Usuario,
Publicación, Comentario, etc.

    Este ejercicio introduce interacciones entre usuarios como agregar amigos y publicaciones.
    Relaciones bidireccionales:
    En agregar_amigo, los usuarios pueden asociarse entre sí al añadir instancias de Usuario a la lista amigos.
    Listas como estructura de historial:
    La lista publicaciones actúa como un registro cronológico de mensajes, que puede ampliarse dinámicamente.
"""


# Clase que representa un usuario
class Usuario:
    def __init__(self, nombre, email):
        # Atributos básicos del usuario
        self.nombre = nombre
        self.email = email
        self.amigos = []  # Lista de amigos
        self.publicaciones = []  # Lista de publicaciones

    def agregar_amigo(self, amigo):
        # Relación bidireccional: agregamos el amigo a la lista
        self.amigos.append(amigo)
        print(f"'{amigo.nombre}' ahora es amigo de '{self.nombre}'.")

    def publicar(self, mensaje):
        # Añadimos un mensaje a la lista de publicaciones
        self.publicaciones.append(mensaje)
        print(f"'{self.nombre}' publicó: {mensaje}")

    def mostrar_perfil(self):
        # Mostramos toda la información del perfil del usuario
        print(f"Perfil de '{self.nombre}':")
        print(f"Email: {self.email}")
        print("Amigos:")
        for amigo in self.amigos:
            print(f"- {amigo.nombre}")
        print("Publicaciones:")
        for publicacion in self.publicaciones:
            print(f"- {publicacion}")


# Creamos usuarios
usuario1 = Usuario(nombre="Lucas", email="LucasBrandan@gmail.com")
usuario2 = Usuario(nombre="Candela", email="Cande@gmail.com")

# Los usuarios se agregan como amigos mutuamente
usuario1.agregar_amigo(usuario2)
usuario2.agregar_amigo(usuario1)

# Publican mensajes
usuario1.publicar("27/04/2012 <3.")
usuario2.publicar("Hoy es un gran día <3")

# Mostramos los perfiles de los usuarios
usuario1.mostrar_perfil()
usuario2.mostrar_perfil()
# Salida:
# Perfil de 'Candela':
# Email: Cande@gmail.com
# Amigos:
# - Lucas
# Publicaciones:
# - 27/04/2012 <3.
# Perfil de 'Lucas':
# Email: lucasandresbrandan@gmail.com
# Amigos:
# - Candela
# Publicaciones:
# - Hoy es un gran día <3.
