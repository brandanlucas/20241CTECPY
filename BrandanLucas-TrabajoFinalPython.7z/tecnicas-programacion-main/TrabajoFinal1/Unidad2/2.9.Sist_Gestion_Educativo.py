"""
Ejercicio 2.9
Imagina que estás trabajando en un programa de gestión de un sistema educativo. 
Tu tarea es diseñar un conjunto de clases orientadas a objetos para administrar:
estudiantes, profesores, materias y calificaciones. 
Debes crear clases como 'Estudiante', 'Profesor', 'Materias' y 'Calificacion'.
Implementa herencia para representar diferentes niveles de estudiantes, como 'EstudianteRegular' y 'EstudianteAvanzado'. 
Utiliza la composición para gestionar la relación entre estudiantes, materias y calificaciones, 
y asegúrate de que el diseño sea versátil para futuras funcionalidades del sistema educativo.

Relaciones múltiples:
La clase Calificacion une estudiantes, materias y notas, para almacenar y calcular promedios.
Filtrado con listas:
notas = [c.nota for c in self.calificaciones if c.estudiante == estudiante] 
filtra las calificaciones por estudiante de manera dinámica.
"""


# Clase que representa un estudiante
class Estudiante:
    def __init__(self, nombre, curso):
        self.nombre = nombre
        self.curso = curso

# Clase que representa un profesor
class Profesor:
    def __init__(self, nombre, materia):
        self.nombre = nombre
        self.materias = materia

# Clase que representa una asignatura
class Materia:
    def __init__(self, nombre):
        self.nombre = nombre

# Clase que representa una calificación
class Calificacion:
    def __init__(self, estudiante, materia, nota):
        self.estudiante = estudiante
        self.materia = materia
        self.nota = nota

# Clase para gestionar el sistema educativo
class SistemaEducativo:
    def __init__(self):
        # Listas para almacenar las entidades del sistema
        self.estudiantes = []
        self.profesores = []
        self.materias = []
        self.calificaciones = []

    def registrar_estudiante(self, estudiante):
        self.estudiantes.append(estudiante)
        print(f"Estudiante '{estudiante.nombre}' registrado.")

    def registrar_profesor(self, profesor):
        self.profesores.append(profesor)
        print(f"Profesor '{profesor.nombre}' registrado.")

    def registrar_materia(self, materia):
        self.materias.append(materia)
        print(f"Materia '{materia.nombre}' registrada.")

    def registrar_calificacion(self, calificacion):
        self.calificaciones.append(calificacion)
        print(f"Calificación registrada: {calificacion.nota} para {calificacion.estudiante.nombre} en {calificacion.materia.nombre}.")

    def calcular_promedio(self, estudiante):
        # Calculamos el promedio de las calificaciones del estudiante
        notas = [c.nota for c in self.calificaciones if c.estudiante == estudiante]
        promedio = sum(notas) / len(notas) if notas else 0
        print(f"Promedio de {estudiante.nombre}: {promedio:.2f}")
        return promedio





# Ejemplo Ejecución
# Creamos instancias del sistema, estudiantes, profesores y materias
sistema = SistemaEducativo()

estudiante1 = Estudiante(nombre="Lucas", curso="Analisis en Sistemas")
profesor1 = Profesor(nombre="Bonini", materia="Técnicas de programación")
materia1 = Materia(nombre="Ténicas de programación")

sistema.registrar_estudiante(estudiante1)
sistema.registrar_profesor(profesor1)
sistema.registrar_materia(materia1)

# Registramos calificaciones
calificacion1 = Calificacion(estudiante=estudiante1, materia=materia1, nota=8)
calificacion2 = Calificacion(estudiante=estudiante1, materia=materia1, nota=9)
sistema.registrar_calificacion(calificacion1)
sistema.registrar_calificacion(calificacion2)

# Calculamos el promedio del estudiante
sistema.calcular_promedio(estudiante1)
