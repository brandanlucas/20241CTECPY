"""
Ejercicio 2.6

Implementa un sistema de reservas para un cine que permita a los usuarios
reservar asientos para películas. Debe haber clases como Pelicula, SalaCine,
Reserva, etc.

    Este ejercicio introduce reservas, combinando múltiples entidades como películas y salas.
    Introducimos el manejo de restricciones (verificar capacidad de asientos)

    Control de restricciones:
    Antes de crear una reserva, verificamos si la sala tiene capacidad suficiente (if sala.capacidad >= asientos).
    Reducimos dinámicamente la capacidad disponible tras realizar una reserva exitosa.
    Uso de listas para gestionar relaciones:
    La lista reservas almacena objetos Reserva, que contienen referencias tanto a una película como a una sala. 
    Esto simula cómo funcionan bases de datos relacionales.
"""


# Clase que representa una película
class Pelicula:
    def __init__(self, titulo, duracion):
        # Atributos básicos de una película
        self.titulo = titulo
        self.duracion = duracion  # Duración en minutos

# Clase que representa una sala de cine
class SalaCine:
    def __init__(self, numero_sala, capacidad):
        # Atributos básicos de una sala
        self.numero_sala = numero_sala
        self.capacidad = capacidad  # Cantidad máxima de asientos

# Clase que representa una reserva
class Reserva:
    def __init__(self, pelicula, sala, asientos_reservados):
        # Relacionamos una película y una sala con la cantidad de asientos reservados
        self.pelicula = pelicula
        self.sala = sala
        self.asientos_reservados = asientos_reservados

# Clase principal que gestiona el sistema de reservas
class SistemaReservas:
    def __init__(self):
        # Lista de reservas realizadas
        self.reservas = []

    def realizar_reserva(self, pelicula, sala, asientos):
        # Comprobamos si hay suficientes asientos disponibles en la sala
        if sala.capacidad >= asientos:
            # Creamos una nueva reserva y la añadimos a la lista
            reserva = Reserva(pelicula, sala, asientos)
            self.reservas.append(reserva)
            # Reducimos la capacidad disponible en la sala
            sala.capacidad -= asientos
            print(f"Reserva realizada: {asientos} asientos para '{pelicula.titulo}' en la sala {sala.numero_sala}.")
        else:
            print("No hay suficientes asientos disponibles en esta sala.")

    def mostrar_reservas(self):
        # Este bucle recorre todas las reservas realizadas y las muestra
        print("Reservas realizadas:")
        for reserva in self.reservas:
            print(f"- {reserva.asientos_reservados} asientos para '{reserva.pelicula.titulo}' en sala {reserva.sala.numero_sala}.")


# Ejemplo Ejecución
# Creamos películas
pelicula1 = Pelicula(titulo="Avatar", duracion=148)
pelicula2 = Pelicula(titulo="Harry Potter", duracion=169)

# Creamos salas de cine
sala1 = SalaCine(numero_sala=1, capacidad=100)
sala2 = SalaCine(numero_sala=2, capacidad=50)

# Creamos el sistema de reservas
sistema = SistemaReservas()

# Realizamos reservas
sistema.realizar_reserva(pelicula=pelicula1, sala=sala1, asientos=30)
sistema.realizar_reserva(pelicula=pelicula2, sala=sala2, asientos=20)
sistema.realizar_reserva(pelicula=pelicula1, sala=sala1, asientos=80)  # Fallará, no hay suficientes asientos

# Mostramos las reservas realizadas
sistema.mostrar_reservas()
# Salida:
# Reserva realizada: 30 asientos para 'Avatar' en la sala 1.
# Reserva realizada: 20 asientos para 'IHarry Potter' en la sala 2.
# No hay suficientes asientos disponibles en esta sala.
# Reservas realizadas:
# - 30 asientos para 'Avatar' en sala 1.
# - 20 asientos para 'Harry Potter' en sala 2.
