"""
Ejercicio 2.5
Desarrolla un simulador de una ciudad donde puedas controlar aspectos
como la población, la economía, la seguridad, etc. Crea clases como
Ciudadano, Edificio, Vehículo, etc.

    Este ejercicio simula una ciudad gestionando diferentes elementos: ciudadanos, edificios y vehículos.
    Introducimos la composición, gestionando múltiples clases dentro de "Ciudad"
"""


# Clase que representa a un ciudadano
class Ciudadano:
    def __init__(self, nombre):
        self.nombre = nombre

# Clase que representa un edificio
class Edificio:
    def __init__(self, nombre, tipo):
        self.nombre = nombre
        self.tipo = tipo  # Por ejemplo: "residencial", "comercial"

# Clase que representa un vehículo
class Vehiculo:
    def __init__(self, marca, modelo):
        self.marca = marca
        self.modelo = modelo

# Clase Ciudad que integra ciudadanos, edificios y vehículos
class Ciudad:
    def __init__(self, nombre):
        # Nombre de la ciudad y listas para gestionar sus elementos
        self.nombre = nombre
        self.poblacion = []
        self.edificios = []
        self.vehiculos = []

    def agregar_ciudadano(self, ciudadano):
        # Método para agregar ciudadanos a la población
        self.poblacion.append(ciudadano)

    def agregar_edificio(self, edificio):
        # Método para agregar edificios a la ciudad
        self.edificios.append(edificio)

    def agregar_vehiculo(self, vehiculo):
        # Método para agregar vehículos
        self.vehiculos.append(vehiculo)

    def mostrar_ciudad(self):
        # Método para mostrar toda la información de la ciudad
        print(f"Ciudad: {self.nombre}")
        print("Población:")
        for ciudadano in self.poblacion:
            print(f"- {ciudadano.nombre}")
        print("Edificios:")
        for edificio in self.edificios:
            print(f"- {edificio.nombre} ({edificio.tipo})")
        print("Vehículos:")
        for vehiculo in self.vehiculos:
            print(f"- {vehiculo.marca} {vehiculo.modelo}")


# Ejemplo Ejecución:
# Creamos la ciudad
mi_ciudad = Ciudad(nombre="Potrerillos")

# Agregamos ciudadanos
ciudadano1 = Ciudadano(nombre="Candela")
ciudadano2 = Ciudadano(nombre="Lucas")
mi_ciudad.agregar_ciudadano(ciudadano1)
mi_ciudad.agregar_ciudadano(ciudadano2)

# Agregamos edificios
edificio1 = Edificio(nombre="Pura Vida", tipo="Cabaña")
edificio2 = Edificio(nombre="Residencial Norte", tipo="Residencial")
mi_ciudad.agregar_edificio(edificio1)
mi_ciudad.agregar_edificio(edificio2)

# Agregamos vehículos
vehiculo1 = Vehiculo(marca="Jeep", modelo="Renegade")
vehiculo2 = Vehiculo(marca="Toyota", modelo="Corolla")
mi_ciudad.agregar_vehiculo(vehiculo1)
mi_ciudad.agregar_vehiculo(vehiculo2)

# Mostramos los detalles de la ciudad
mi_ciudad.mostrar_ciudad()
# Salida:
# Ciudad: Potrerillos
# Población:
# - Candela
# - Lucas
# Edificios:
# - Pura Vida (Cabaña)
# - Residencial Norte (Residencial)
# Vehículos:
# - Jeep Renegade
# - Toyota Corolla

