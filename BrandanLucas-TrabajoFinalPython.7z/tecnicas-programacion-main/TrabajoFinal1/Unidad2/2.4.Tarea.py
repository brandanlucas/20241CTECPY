"""
Ejercicio 2.4
Crea un sistema de gestión de tareas que permita a los usuarios agregar, eliminar y actualizar tareas. 
Debe haber clases como Tarea, ListaTareas, etc.

    Introducimos el uso de métodos avanzados como actualizaciones y eliminaciones usando expresiones de lista.
    Este ejercicio introduce la gestión de tareas, similar al manejo de productos pero con acciones específicas.
"""


# Clase que representa una tarea individual
class Tarea:
    def __init__(self, nombre, descripcion):
        # Cada tarea tiene un nombre y una descripción
        self.nombre = nombre
        self.descripcion = descripcion

# Clase ListaTareas para gestionar varias tareas
class ListaTareas:
    def __init__(self):
        # La lista "tareas" almacena objetos Tarea
        self.tareas = []

    def agregar_tarea(self, tarea):
        # Agrega una tarea a la lista
        self.tareas.append(tarea)
        print(f"Tarea '{tarea.nombre}' agregada.")

    def eliminar_tarea(self, nombre):
        # Este bucle filtra las tareas para eliminar la que coincida con el nombre
        self.tareas = [tarea for tarea in self.tareas if tarea.nombre != nombre]
        print(f"Tarea '{nombre}' eliminada, si existía.")

    def actualizar_tarea(self, nombre, nueva_descripcion):
        # Recorremos la lista buscando la tarea con el nombre especificado
        for tarea in self.tareas:
            if tarea.nombre == nombre:
                tarea.descripcion = nueva_descripcion
                print(f"Tarea '{nombre}' actualizada con nueva descripción: {nueva_descripcion}")
                break

    def mostrar_tareas(self):
        # Este bucle muestra todas las tareas almacenadas
        print("Lista de tareas:")
        for tarea in self.tareas:
            print(f"- {tarea.nombre}: {tarea.descripcion}")



# Ejemplo Ejecución
# Creamos una lista de tareas
mis_tareas = ListaTareas()

# Creamos y agregamos tareas a la lista
tarea1 = Tarea(nombre="Comprar alimentos", descripcion="Ir al supermercado y comprar pan y leche.")
tarea2 = Tarea(nombre="Estudiar Python", descripcion="Revisar clases de objetos y herencia.")
mis_tareas.agregar_tarea(tarea1)
mis_tareas.agregar_tarea(tarea2)

# Mostramos las tareas iniciales
mis_tareas.mostrar_tareas()
# Salida:
# Lista de tareas:
# - Comprar alimentos: Ir al supermercado y comprar pan y leche.
# - Estudiar Python: Revisar clases de objetos y herencia.

# Actualizamos una tarea
mis_tareas.actualizar_tarea(nombre="Estudiar Python", nueva_descripcion="Practicar ejercicios de listas en Python.")

# Eliminamos una tarea
mis_tareas.eliminar_tarea(nombre="Comprar alimentos")

# Mostramos las tareas restantes
mis_tareas.mostrar_tareas()
# Salida:
# Lista de tareas:
# - Estudiar Python: Practicar ejercicios de listas en Python.

