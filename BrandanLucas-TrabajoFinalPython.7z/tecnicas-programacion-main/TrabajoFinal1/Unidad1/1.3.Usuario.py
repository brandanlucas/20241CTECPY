"""
Ejercicio 1.3
Crea una clase Usuario con atributos como nombre, email y contraseña. 
Crea métodos para cambiar la contraseña y para mostrar la información del usuario.
"""

class Usuario:
    def __init__(self, nombre, email, contrasena):
        self.nombre = nombre
        self.email = email
        self.contrasena = contrasena

    def cambiar_contrasena(self, nueva_contrasena):
        self.contrasena = nueva_contrasena
    
    def mostrar_informacion(self):
        print(f"Nombre: {self.nombre}")
        print(f"Email: {self.email}")


usuario1 = Usuario("Pablo", "Pabloa.salvio@gmail.com", "123456")
usuario1.mostrar_informacion()
