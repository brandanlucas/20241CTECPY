"""
Ejercicio 1.11
Crea una clase abstracta llamada Animal que tenga métodos abstractos
como hacer_sonido() y moverse(). Luego, crea clases concretas como Perro,
Gato, Pájaro, etc., que hereden de Animal y proporcionen implementaciones
concretas para estos métodos.
"""

from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def hacer_sonido(self):
        pass
    def moverse(self):
        pass

class Perro(Animal):
    def hacer_sonido(self):
        print("Guaf Guaf")
    def moverse(self):
        print("El perro está corriendo")


class Pajaro(Animal):
    def hacer_sonido(self):
        print("El pajaro esta cantando")
    def moverse(self):
        print("El pajaro esta volando")

perrito1 = Perro()
perrito1.hacer_sonido()
perrito1.moverse()

pajaro1 = Pajaro()
pajaro1.hacer_sonido()
pajaro1.moverse()