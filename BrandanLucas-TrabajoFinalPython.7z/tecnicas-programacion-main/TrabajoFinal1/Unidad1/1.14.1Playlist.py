"""
Ejercicio 1.14
Define una clase Playlist que tenga una lista de canciones. Usa composición
para representar la relación entre una lista de reproducción y las canciones
que la componen.
"""
class Cancion:
    def __init__(self, nombre, artista):
        self.nombre = nombre
        self.artista = artista

    def reproducir(self):
        print(f"Reproduciendo {self.nombre} de {self.artista}")

class Playlist:
    def __init__(self):
        self.canciones = []

    def agregar_cancion(self, cancion):
        self.canciones.append(cancion)

    def reproducir_todas(self):
        for cancion in self.canciones:
            cancion.reproducir()
