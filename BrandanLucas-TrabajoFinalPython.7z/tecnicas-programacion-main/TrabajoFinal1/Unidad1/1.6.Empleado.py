"""
Ejercicio 1.6
Crea una clase Empleado con atributos como nombre, salario y departamento. 
Crea clases derivadas como Desarrollador, Diseñador, etc., que añadan 
atributos y métodos propios de cada tipo de empleado.
"""

class Empleado:
     def __init__ (self, nombre, salario, departamento):
          self.nombre = nombre
          self.salario = salario
          self.departamento = departamento

class Desarrollador(Empleado):
     def __init__ (self, nombre, salario, departamento, lenguajes):
          self.lenguajes = lenguajes
          super().__init__(nombre, salario, departamento)


          

Desarrollador1 = Desarrollador ("Ricardo", "1900 USD","IT", "Java")
print(f"El nombre del desarrollador es: {Desarrollador1.nombre}")
print(f"El salario del desarrollador es: {Desarrollador1.salario}")
print(f"El departamento del desarrollador es: {Desarrollador1.departamento}")
print(f"El lenguaje del desarrollador es: {Desarrollador1.lenguajes}")


