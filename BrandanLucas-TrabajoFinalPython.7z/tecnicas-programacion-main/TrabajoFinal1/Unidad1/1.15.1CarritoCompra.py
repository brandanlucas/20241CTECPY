"""
Ejercicio 1.15
Crea una clase CarritoCompra que tenga una lista de productos. Usa
agregación para representar la relación entre un carrito de compra y los
productos que contiene.
"""

class Producto:
    def __init__(self, nombre, precio):
        self.nombre = nombre
        self.precio = precio

class CarritoCompra:
    def __init__(self):
        self.productos = []

    def agregar_producto(self, producto):
        self.productos.append(producto)

    def mostrar_carrito(self):
        for producto in self.productos:
            print(f"Producto: {producto.nombre}, Precio: {producto.precio}")
