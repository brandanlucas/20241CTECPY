"""
Ejercicio 1.10
Crea una clase Producto con un método calcular_precio_descuento(). Luego,
crea clases derivadas como ProductoDescuento, ProductoNormal, etc., que
implementen este método de manera diferente
"""
class Producto:
    def __init__(self, nombre, precio):
        self.nombre = nombre
        self.precio = precio
        
def calcular_precio_descuento(self):
        return self.precio

class ProductoDescuento(Producto):
    def __init__(self, nombre, precio, porcentaje_descuento):
        super().__init__(nombre, precio)
        self.porcentaje_descuento = porcentaje_descuento

    def calcular_precio_descuento(self):
        descuento = self.precio * (self.porcentaje_descuento / 100)
        return self.precio - descuento
    
class ProductoNormal(Producto):
    def calcular_precio_descuento(self):
        # No aplica descuento, devuelve el precio original
        return self.precio
    

producto2 = ProductoDescuento ("Canilla", 100, 20)
print(f"El producto 1 es: {producto2.nombre}, el precio es {producto2.precio} y el precio con descuento es: {producto2.calcular_precio_descuento()}")






