"""
Ejercicio 1.8
Define una clase Figura con métodos como calcular_area() y
calcular_perimetro(). Luego, crea clases derivadas como Triangulo,
Cuadrado, etc., que sobrescriban estos métodos para calcular el área y
perímetro de cada figura.
"""

from abc import ABC, abstractmethod

class Figura(ABC):
    @abstractmethod
    def calcular_area(self):
        pass

    @abstractmethod
    def calcular_perimetro(self):
        pass

class Triangulo(Figura):
    def __init__(self, base, altura, lado1, lado2, lado3):
        self.base = base
        self.altura = altura
        self.lado1 = lado1
        self.lado2 = lado2
        self.lado3 = lado3

    def calcular_area(self):
        return (self.base * self.altura) / 2

    def calcular_perimetro(self):
        return self.lado1 + self.lado2 + self.lado3

class Cuadrado(Figura):
    def __init__(self, lado):
        self.lado = lado

    def calcular_area(self):
        return self.lado ** 2

    def calcular_perimetro(self):
        return 4 * self.lado

# Ejemplo de uso
triangulo = Triangulo(base=5, altura=4, lado1=5, lado2=4, lado3=3)
print(f"Área del triángulo: {triangulo.calcular_area()}")
print(f"Perímetro del triángulo: {triangulo.calcular_perimetro()}")

cuadrado = Cuadrado(lado=4)
print(f"Área del cuadrado: {cuadrado.calcular_area()}")
print(f"Perímetro del cuadrado: {cuadrado.calcular_perimetro()}")
