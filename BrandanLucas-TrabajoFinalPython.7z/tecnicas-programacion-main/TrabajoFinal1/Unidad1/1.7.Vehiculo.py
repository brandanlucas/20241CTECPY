"""
Ejercicio 1.7
Crea una clase base Vehiculo con atributos como marca, modelo y color.
Luego, crea clases derivadas como Coche, Moto, etc., que hereden de
Vehiculo y agreguen atributos y métodos específicos.
"""

class Vehiculo:
    def __init__(self, marca, modelo, color, cantRuedas):
        self.marca = marca
        self.modelo = modelo
        self.color = color
        self.cantRuedas = cantRuedas
    
class Coche(Vehiculo):
    def __init__(self, marca, modelo, color, cantRuedas, cantPuertas):
        super().__init__(marca, modelo, color, cantRuedas)
        self.cantPuertas = cantPuertas

class Moto(Vehiculo):
    def __init__(self, marca, modelo, color, cantRuedas, cantCilindradas):
        super().__init__(marca, modelo, color, cantRuedas)
        self.cantCilindradas = cantCilindradas

        


Coche1 = Coche("Fiat", "Cronos", "Rojo", 4, 5)
Moto1 = Moto ("Zanella", "110", "Blanca", 1, 110)

print(f"La marca del coche es: {Coche1.marca}, el modelo es: {Coche1.modelo}, el color es: {Coche1.color}, tiene: {Coche1.cantRuedas} ruedas y tiene {Coche1.cantPuertas} puertas")
print(f"La marca de la moto es: {Moto1.marca}, el modelo es: {Moto1.modelo}, el color es: {Moto1.color}, tiene: {Moto1.cantRuedas} ruedas y es de {Moto1.cantCilindradas} cilindradas")