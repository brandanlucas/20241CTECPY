"""
Ejercicio 1.9
Crea una función reproducir() que acepte cualquier objeto que represente un
medio de entretenimiento (como una canción, película, libro, etc.) y lo
reproduzca
"""


class Cancion:
    def __init__(self, nombre, artista, duracion):
        self.nombre = nombre
        self.artista = artista
        self.duracion = duracion
    
    def reproducir(self):
        print(f"Reproduciendo canción: {self.nombre}")

class Pelicula:
    def __init__(self, nombre, director, duracion):
        self.nombre = nombre 
        self.director = director
        self.duracion = duracion
    def reproducir(self):
        print (f"Viendo Pelicula: {self.nombre}")

pelicula1 = Pelicula ("Gladiador", "Ridley Scott", 120)
cancion1 = Cancion("Como Ali", "Los Piojos", 5)

cancion1.reproducir()
pelicula1.reproducir()

