"""
Ejercicio 1.12
Define una clase abstracta llamada Empleado que tenga métodos abstractos
como calcular_sueldo() y generar_reporte(). Luego, crea clases concretas
como Desarrollador, Gerente, Contador, etc., que hereden de Empleado y
proporcionen implementaciones concretas para estos métodos
"""

from abc import ABC, abstractmethod

class Empleado(ABC):
    def __init__(self, nombre, salario):
        self.nombre = nombre
        self.salario = salario

    @abstractmethod
    def calcular_sueldo(self):
        pass

    @abstractmethod
    def generar_reporte(self):
        pass

class Desarrollador(Empleado):
    def calcular_sueldo(self):
        return self.salario

    def generar_reporte(self):
        print(f"Desarrollador: {self.nombre}, Salario: {self.salario}")

class Gerente(Empleado):
    def calcular_sueldo(self):
        return self.salario + 5000

    def generar_reporte(self):
        print(f"Gerente: {self.nombre}, Salario: {self.salario}")

                       
