"""
Ejercicio 1.1
Crea una clase llamada Producto que tenga atributos como nombre, precio y cantidad_disponible.
Implementa métodos para actualizar la cantidad disponible y para mostrar la información del producto.
"""

class Producto:
    def __init__(self, nombre, precio, cantidad_disponible):
        self.nombre = nombre
        self.precio = precio
        self.cantidad_disponible = cantidad_disponible


    def actualizar_cantidad(self, nueva_cantidad):
        self.cantidad_disponible = nueva_cantidad

    def mostrar_informacion(self):
        print(f"Nombre del Producto: {self.nombre}")
        print(f"Precio: {self.precio}")
        print(f"Cantidad Disponible: {self.cantidad_disponible}")
    

producto1 = Producto("Manzana", 15.0, 100)
producto1.mostrar_informacion()



