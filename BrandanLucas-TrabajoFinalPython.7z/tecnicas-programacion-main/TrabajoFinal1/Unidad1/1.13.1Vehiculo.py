"""
Ejercicio 1.13
Crea una clase abstracta llamada Vehiculo que tenga métodos abstractos
como acelerar() y frenar(). Luego, crea clases concretas como Coche, Moto,
Bicicleta, etc., que hereden de Vehiculo y proporcionen implementaciones
concretas para estos métodos.
"""

from abc import ABC, abstractmethod

class Vehiculo(ABC):
    def __init__(self, marca, modelo, color):
        self.marca = marca
        self.modelo = modelo
        self.color = color

    @abstractmethod
    def acelerar(self):
        pass

    @abstractmethod
    def frenar(self):
        pass

class Coche(Vehiculo):
    def acelerar(self):
        print(f"El coche {self.marca} está acelerando")

    def frenar(self):
        print(f"El coche {self.marca} está frenando")

class Moto(Vehiculo):
    def acelerar(self):
        print(f"La moto {self.marca} está acelerando")

    def frenar(self):
        print(f"La moto {self.marca} está frenando")
